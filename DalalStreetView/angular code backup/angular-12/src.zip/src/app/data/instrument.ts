
  export class Instrument {
    constructor(public instrumentToken: number,  public tradingSymbol: string) { }
  }
