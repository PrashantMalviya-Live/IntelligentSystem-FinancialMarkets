export function getBaseUrl() {
  return document.getElementsByTagName('base')[0].href;
}
