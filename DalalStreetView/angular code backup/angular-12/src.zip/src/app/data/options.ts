export class Options {
  constructor(public instrumentToken: number, public tradingSymbol: string, public strike: string, public type: string) { }
}
