export class Expiry {
 constructor(public id: number, public instid: number, public value: string) { }
}